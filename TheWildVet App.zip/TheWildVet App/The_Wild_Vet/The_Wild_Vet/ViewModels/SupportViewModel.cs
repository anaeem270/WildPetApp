﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using The_Wild_Vet.Models;
using Xamarin.Forms;
using The_Wild_Vet.Views;

namespace The_Wild_Vet.ViewModels
{
    public class SupportViewModel : BaseViewModel
    {
        public ObservableCollection<IssueModel> Issues { get; set; }
        public IssueModel SelectedIssue { get; set; }
        public SymptomModel SelectedSymptom { get; set; }
        public OccurrenceModel SelectedOccurrence { get; set; }

        public bool HavingResult { get; set; }
        public bool NotHavingResult { get => !HavingResult; }

        public SupportViewModel()
        {
            InitData().ConfigureAwait(true);
        }

        async Task InitData()
        {
            //retrieve all issues from json
            var issues = ApiService.GetAllIssues();

            //display all issues if it isn't empty
            if (issues != null)
            {
                Issues = new ObservableCollection<IssueModel>(issues);
            }
        }


        //Command for done button
        ICommand _DoneCommand;
        public ICommand DoneCommand => (_DoneCommand = _DoneCommand ?? new Command<object>(ExecuteDoneCommand));
        async void ExecuteDoneCommand(object parameter)
        {
            PushPageAsync(new DashboardPage());
        }   


        //Command for next button
        ICommand _NextCommand;
        public ICommand NextCommand => (_NextCommand = _NextCommand ?? new Command<object>(ExecuteNextCommand));
        async void ExecuteNextCommand(object parameter)
        {
            if (SelectedIssue != null && SelectedSymptom != null && SelectedOccurrence != null)
            {

                HavingResult = true;
            }
            else
            {
                await App.Current.MainPage.DisplayAlert("Oops!","Please fill in all the provided fields!","OK");
            }
        }

        //Command for Call us button
        ICommand _CallCommand;
        public ICommand CallCommand => (_CallCommand = _CallCommand ?? new Command<object>(ExecuteCallCommand));
        void ExecuteCallCommand(object parameter)
        {
            try
            {
                Xamarin.Essentials.PhoneDialer.Open(PhoneConstant.VetPhoneNumber);
            }
            catch (Exception ex)
            {

            }
        }
    }
}
