﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Plugin.Media.Abstractions;
using The_Wild_Vet.Models;
using Xamarin.Forms;
using The_Wild_Vet.Views;
using Plugin.Media;
using System.IO;

namespace The_Wild_Vet.ViewModels
{
    public class RegisterationDetailsShowViewModel : BaseViewModel
    {
        MediaFile file;
        // public ObservableCollection<PersonModel> Person { get; set; }

        public PersonModel CurrentPersonLogin { get; set; }

        public Xamarin.Forms.ImageSource Sourced { get; set; }

        public RegisterationDetailsShowViewModel()
        {
            InitData().ConfigureAwait(true);
           
        }

        async Task InitData()
        {
            IsBusyIndicator = true;

            CurrentPersonLogin = await ApiService.GetPerson(ApiService.CurrentEmailId);

            IsBusyIndicator = false;

        }


        ICommand _ButtonClicked;
        public ICommand ButtonClicked => new Command(ExecuteSelectCommand);
        

        //Command to upload image when selected
        async void ExecuteSelectCommand()
        {

            UploadImage();
        }


        private async void UploadImage()
        {
            await CrossMedia.Current.Initialize();
            try
            {

                file = await Plugin.Media.CrossMedia.Current.PickPhotoAsync(new Plugin.Media.Abstractions.PickMediaOptions
                {
                    PhotoSize = Plugin.Media.Abstractions.PhotoSize.Medium
                });
                if (file == null)
                    return;

                // to store image refrence in sourced
                Sourced = await ApiService.UploadFile(file.GetStream(), Path.GetFileName(file.Path));

                // to update image source on the firebase database
                var uri = Sourced.GetValue(UriImageSource.UriProperty);
                await ApiService.UpdatePerson( uri.ToString());
                PushPageAsync(new ProfilePage());
            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        //Command for Done button
        ICommand _DoneCommand;
        public ICommand DoneCommand => (_DoneCommand = _DoneCommand ?? new Command<object>(ExecuteDoneCommand));
        async void ExecuteDoneCommand(object parameter)
        {
                await App.Current.MainPage.DisplayAlert("Success!", "You have successfully changed Person Details!", "OK");
                PushPageAsync(new DashboardPage());
        }
    }
}
