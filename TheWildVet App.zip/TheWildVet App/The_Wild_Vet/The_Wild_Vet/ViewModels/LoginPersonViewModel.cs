﻿using System;



using Xamarin.Forms;

namespace The_Wild_Vet.ViewModels
{
    public class LoginPersonViewModel : BaseViewModel
    {
       


        public string CurrentEmailId { get; set;}


        // geting login details of a person and sending it to api service for further use in other classes
        public LoginPersonViewModel(string EmailIds)
        {
         
            ApiService.CurrentEmailId = EmailIds;
      
        }
       
    }
}

