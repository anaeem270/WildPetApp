﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using The_Wild_Vet.Models;
using Xamarin.Forms;
using The_Wild_Vet.Views;

namespace The_Wild_Vet.ViewModels
{
    public class ParasiteProductViewModel: BaseViewModel 
    {
       public ObservableCollection<TypeModel> TypePet { get; set; }
       public TypeModel selectedType { get; set; }
       public FulfilmentModel selectedFulfilment { get; set; }
       public ChildModel selectedChild { get; set; }
       public PetModel selectedPet { get; set; }
       public ObservableCollection<PetModel> AllPets { get; set; }


       public bool Result { get; set; }
       public bool noResult { get => !Result; }

       public ParasiteProductViewModel()
        {
            InitData().ConfigureAwait(true);
        }

        async Task InitData()
        {
            //Retrieve all the parasite products from json file
            var types = ApiService.GetAllProducts();

            //Display type of pet if it is not empty
            if(types != null )
            {
                TypePet = new ObservableCollection<TypeModel>(types);
            }

            // await Application.Current.MainPage.DisplayAlert("AA", , "Ok");

            //Retrieve all the pets from the current email
            var pets = await ApiService.GetPet(ApiService.CurrentEmailId);

            //Display all the pets if it is not empty
            if (pets != null)
            {
               AllPets = new ObservableCollection<PetModel>(pets);


            }
        }

        //Command for Next Button
        ICommand _NextCommand;
        public ICommand NextCommand => (_NextCommand = _NextCommand ?? new Command<object>(ExecuteNextCommand));
        async void ExecuteNextCommand(object parameter)
        {
            if (selectedType != null && selectedFulfilment != null && selectedChild != null)
            {
                Result = true;
            }

            else
            {
                await App.Current.MainPage.DisplayAlert("Oops!", "Please fill in all the fields provided!", "OK");
            }
        }

        //Command for Done Button
        ICommand _DoneCommand;
        public ICommand DoneCommand => (_DoneCommand = _DoneCommand ?? new Command<object>(ExecuteDoneCommand));
        async void ExecuteDoneCommand(object parameter)
        {

            PushPageAsync(new DashboardPage());

        }

        //Command for Call us button
        ICommand _CallCommand;
        public ICommand CallCommand => (_CallCommand = _CallCommand ?? new Command<object>(ExecuteCallCommand));
        void ExecuteCallCommand(object parameter)
        {
            try
            {
                Xamarin.Essentials.PhoneDialer.Open(PhoneConstant.VetPhoneNumber);
            }
            catch (Exception ex)
            {
                Application.Current.MainPage.DisplayAlert("Alert", ""+ex , "Ok");
            }
        }
    }
}
