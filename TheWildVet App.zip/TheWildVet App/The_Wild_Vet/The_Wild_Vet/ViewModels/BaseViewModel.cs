﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using The_Wild_Vet.Services;
using Xamarin.Forms;

namespace The_Wild_Vet.ViewModels
{
    //A base view model that other view models can refer to
    public class BaseViewModel : INotifyPropertyChanged
    {
        private bool _isBusy;

        public bool IsBusyIndicator
        {
            get { return _isBusy; }

            set { _isBusy = value; OnPropertyChanged(); }

        }

        public RestfulApiService ApiService = RestfulApiService.Instance;
    


        bool isBusy = false;
        public bool IsBusy
        {
            get { return isBusy; }
            set { SetProperty(ref isBusy, value); }
        }

        string title = string.Empty;
        public string Title
        {
            get { return title; }
            set { SetProperty(ref title, value); }
        }

        protected bool SetProperty<T>(ref T backingStore, T value,
            [CallerMemberName] string propertyName = "",
            Action onChanged = null)
        {
            if (EqualityComparer<T>.Default.Equals(backingStore, value))
                return false;

            backingStore = value;
            onChanged?.Invoke();
            OnPropertyChanged(propertyName);
            return true;
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            var changed = PropertyChanged;
            if (changed == null)
                return;

            changed.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

        public void PushPageAsync(ContentPage page)
        {
            if (App.Current.MainPage is FlyoutPage flyoutPage && flyoutPage.Detail is NavigationPage navigationPage)
            {
                navigationPage.Navigation.PushAsync(page);
            }
            else if (App.Current.MainPage is NavigationPage navPage)
            {
                navPage.Navigation.PushAsync(page);
            }
        }

  
        public void GoBackAsync() {
            if (App.Current.MainPage is FlyoutPage flyoutPage && flyoutPage.Detail is NavigationPage navigationPage)
            {
                navigationPage.Navigation.PopAsync();
            }
            else if (App.Current.MainPage is NavigationPage navPage)
            {
                navPage.Navigation.PopAsync();
            }
        }


        
    }
}
