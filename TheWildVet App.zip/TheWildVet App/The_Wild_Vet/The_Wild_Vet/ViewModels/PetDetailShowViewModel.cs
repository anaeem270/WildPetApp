﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using The_Wild_Vet.Models;
using The_Wild_Vet.Services;
using Xamarin.Forms;
using Firebase.Storage;
using The_Wild_Vet.Views;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Xamarin.Forms.Xaml;
using System.Diagnostics;
using System.IO;

namespace The_Wild_Vet.ViewModels
{
    public class PetDetailShowViewModel : BaseViewModel
    {

        public Xamarin.Forms.ImageSource Sourced { get; set; }

        public PetModel MyPets { get; set; }
   
        public string CurrentPetname { get; set; }

        //RestfulApiService ApiService = new RestfulApiService();

        PersonModel Currentperson = new PersonModel();
        MediaFile file;
        public PetDetailShowViewModel()
        {
            InitData().ConfigureAwait(true);
     
        }


        // Image of Pet clicked to call Image Upload Method

          public object Likewise { get; private set; }
          public ICommand ButtonClicked => new Command(ExecuteSelectCommand);

           void ExecuteSelectCommand()
          {

              UploadImage();
          }



        // Button to use in emergency to get Support Page.
        public ICommand GetButton => new Command(ExecuteGetCare); 
        async void ExecuteGetCare(object parameter)
        {
            PushPageAsync(new SupportPage());
            
        }

        // Command for button to Edit Current Pet
        public ICommand EditPetClicked =>  new Command (ExecuteEditPetClicked);
        async void ExecuteEditPetClicked()
        {
            PushPageAsync(new ExecuteEditPetClickedPage());
        }


      

        //Command for button to delete Current Pet
        public ICommand DeleteClicked => new Command(ExecuteDeleteCommand);


        async void ExecuteDeleteCommand()
        {

            var res = await App.Current.MainPage.DisplayAlert("Message", "Are you sure you want to Delete Pet?", "Yes", "Cancel");
            if (res)
            {
                IsBusyIndicator = true;
                await ApiService.DeletePet(ApiService.SelectedPet);
                IsBusyIndicator = false;
                PushPageAsync(new DashboardPage());
            }
        }

        // Get Selected Pet Detail.

        async Task InitData()
        {
            IsBusyIndicator = true;

            MyPets = await ApiService.GetPets(ApiService.SelectedPet);

            IsBusyIndicator = false;

        }

        // Update Pet Details
        ICommand _DoneCommand;
        public ICommand DoneCommand => (_DoneCommand = _DoneCommand ?? new Command<object>(ExecuteDoneCommand));
        async void ExecuteDoneCommand(object parameter) { 
           // await ApiService.UpdatePetDetail();
            await App.Current.MainPage.DisplayAlert("Success!", "You have successfully Updated Pet Detail!", "OK");
            PushPageAsync(new PetDetailsPage());
        }

        // Uploads images   
        private async void UploadImage()
        {
            

            await CrossMedia.Current.Initialize();
            try
            {

                file = await Plugin.Media.CrossMedia.Current.PickPhotoAsync(new Plugin.Media.Abstractions.PickMediaOptions
                {
                    PhotoSize = Plugin.Media.Abstractions.PhotoSize.Medium
                });
                if (file == null)
                    return;

                // to store image refrence in sourced
                IsBusyIndicator = true;
                Sourced = await ApiService.UploadFile(file.GetStream(), Path.GetFileName(file.Path));

                // to update image source on the firebase database
                var uri = Sourced.GetValue(UriImageSource.UriProperty);
                await ApiService.UpdatePet(ApiService.SelectedPet, uri.ToString());
                IsBusyIndicator = false;
                PushPageAsync(new PetDetailsPage());
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }



    }

}

