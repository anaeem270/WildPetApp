﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using The_Wild_Vet.Models;
using The_Wild_Vet.Views;
using Xamarin.Forms;
using The_Wild_Vet.Services;


namespace The_Wild_Vet.ViewModels
{
    public class DashboardViewModel : BaseViewModel
    {
        public ObservableCollection<PetModel> Pets { get; set; }

        public string Emailid;
        public DashboardViewModel()
        {
            InitData().ConfigureAwait(true);
           
        }

        async Task InitData()
        {
            IsBusyIndicator = true;

            //retrieve pets associated with the email address
            var pets = await ApiService.GetPet(ApiService.CurrentEmailId);

            // display all pets from json if it isn't empty
            if (pets != null)
            {
                Pets = new ObservableCollection<PetModel>(pets);
                IsBusyIndicator = false;
            }
          
        }

        //Command when selecting pet 
        ICommand _SelectCommand;
        public ICommand SelectCommand => (_SelectCommand = _SelectCommand ?? new Command<object>(ExecuteSelectCommand));
        void ExecuteSelectCommand(object parameter)
        {
           ApiService.SelectedPet = parameter.ToString();
           PushPageAsync(new PetDetailsPage());
        }

        //Add a pet command
        ICommand _AddAPetCommand;
        public ICommand AddAPetCommand => (_AddAPetCommand = _AddAPetCommand ?? new Command<object>(ExecuteAddAPetCommand));
        void ExecuteAddAPetCommand(object parameter)
        {
           
            PushPageAsync(new AddPetDetailPage());
        }
    }
}
