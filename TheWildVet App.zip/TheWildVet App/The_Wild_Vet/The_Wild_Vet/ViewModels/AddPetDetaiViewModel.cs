﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using The_Wild_Vet.Models;
using Xamarin.Forms;
using The_Wild_Vet.Views;

namespace The_Wild_Vet.ViewModels
{
    public class AddPetDetaiViewModel : BaseViewModel
    {
        BreedModel[] breeds;
        public ObservableCollection<BreedModel> Breeds { get; set; }
        public ObservableCollection<BreedModel> BreedTree { get; set; }
        public ObservableCollection<BreedModel> CurrentBreeds { get; set; }

        public BreedModel SelectedBreed { get; set; }

        public string PetName { get; set; }
        public bool IsFemale { get; set; }
        
        public double? WeightInGams { get; set; }
        public string DoB { get; set; }
        public bool Microchipped { get; set; }
        public string Color { get; set; }
        public string Gender { get; set; }

        // default image add pet image
        public string ImageUrl = "https://firebasestorage.googleapis.com/v0/b/thewildvetapp.appspot.com/o/Pets%2Fadd.png?alt=media&token=8f830377-b78b-4e4e-ab9b-5338bdfa3db0";

        public AddPetDetaiViewModel()
        {
            InitData().ConfigureAwait(true);
        }

        async Task InitData()
        {
            //get breed from json file
            breeds = ApiService.GetAllBreeds();
            WeightInGams = null;

            //if getting data, Init the breedTree the first time to get the first ancestor
            if (breeds != null && breeds.Length > 0)
            {
                Breeds = new ObservableCollection<BreedModel>(breeds);
                CurrentBreeds = new ObservableCollection<BreedModel>(breeds);
                BreedTree = new ObservableCollection<BreedModel>();

                //1st breed level, where children are all breeds
                BreedTree.Add(new BreedModel
                {
                    Id = -1001,
                    Title = "Breeds",
                    Childrens = breeds.ToList()
                });
            }
        }

        //Command for when selecting breed
        ICommand _SelectBreedCommand;
        public ICommand SelectBreedCommand => (_SelectBreedCommand = _SelectBreedCommand ?? new Command<(BreedModel, BreedModel)>(ExecuteSelectBreedCommand));
        void ExecuteSelectBreedCommand((BreedModel, BreedModel) tpbreeds)
        {
            SelectedBreed = tpbreeds.Item2;
            var breed = tpbreeds.Item2;
            // First Level: when first level is selected it will clear all of the dropdown below
            if (tpbreeds.Item1.Id == -1001)
            {
                for (int i = BreedTree.Count - 1; i > 0; i--)
                {
                    BreedTree.RemoveAt(i);
                }
            }

            /* If user selects level 1 or below we will find which level user already selected 
             for example: BreedTree level is:
                        0: snake => 1:python => 2:DiamondPython => 3: etc
             User  then reselects python: existedIndex will be 1 and then we remove dropdown level 1 and 2
             */
            else
            {
                var existedIndex = BreedTree.Select(x => x.Id).ToList().IndexOf(tpbreeds.Item1.Id);
                if (existedIndex > 0)
                {
                    for (int i = BreedTree.Count - 1; i > existedIndex; i--)
                    {
                        BreedTree.RemoveAt(i);
                    }
                }
            }
            //adds new dropdown level with with the child of their parent
            if (breed.Childrens != null && breed.Childrens.Count > 0)
            {
                BreedTree.Add(breed);
            }
        }


        //Command used to select gender of pet
        ICommand _SelectGenderCommand;
        public ICommand SelectGenderCommand => (_SelectGenderCommand = _SelectGenderCommand ?? new Command<string>(ExecuteSelectGenderCommand));
        void ExecuteSelectGenderCommand(string parameter)
        {
            IsFemale = parameter == "F";
          

        }

        //Command used to select whether microchipped or not
        ICommand _SelectChipCommand;
        public ICommand SelectChipCommand => (_SelectChipCommand = _SelectChipCommand ?? new Command<string>(ExecuteSelectChipCommand));
        void ExecuteSelectChipCommand(string parameter)
        {
            Microchipped = parameter == "Y";
        }

        //Command for done button
        ICommand _DoneCommand;
        public ICommand DoneCommand => (_DoneCommand = _DoneCommand ?? new Command<object>(ExecuteDoneCommand));
        async  void ExecuteDoneCommand(object parameter) {

            if (IsFemale.ToString() == "False")
            {
                Gender = "Male";
            }
            else
            { Gender = "Female";  }
            if ( PetName != null && DoB != null && WeightInGams != null && Color != null &&
               Microchipped != true)
            {
                await ApiService.AddPets(PetName, Microchipped, DoB, WeightInGams, Gender, Color, SelectedBreed, ImageUrl, ApiService.CurrentEmailId);
                await App.Current.MainPage.DisplayAlert("Success!", "Your Pet has been successfully added!", "OK");
                PushPageAsync(new DashboardPage());
            }

            else
            {

                await App.Current.MainPage.DisplayAlert("Oops!", "Please fill in all the required fields!", "OK");
            }
        }
    }
}
