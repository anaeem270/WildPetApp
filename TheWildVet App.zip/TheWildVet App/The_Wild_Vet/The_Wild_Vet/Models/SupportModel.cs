﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace The_Wild_Vet.Models
{
    // Used https://app.quicktype.io/ and then pasted the json(using C#).
    public class IssueModel : BaseModel
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("symptoms", NullValueHandling = NullValueHandling.Ignore)]
        public List<SymptomModel> Symptoms { get; set; }
    }

    public class SymptomModel : BaseModel
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("Occurrence")]
        public List<OccurrenceModel> Occurrence { get; set; }
    }

    public class OccurrenceModel : BaseModel
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("outcome")]
        public string Outcome { get; set; }
    }
}
