﻿

using The_Wild_Vet.Services;
using Xamarin.Forms;

namespace The_Wild_Vet.Models
{
    public class PersonModel
    {
        public string PersonId { get; set; }
        public string Name { get; set; }
        public string DateofBirth { get; set; }
        public string Address { get; set; }
        public string Password { get; set; }
        public string ImgUrl { get; set; }
       
    }
   
}
