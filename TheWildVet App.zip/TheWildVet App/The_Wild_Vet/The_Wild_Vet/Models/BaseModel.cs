﻿using System;
using System.ComponentModel;

namespace The_Wild_Vet.Models
{
    public class BaseModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
