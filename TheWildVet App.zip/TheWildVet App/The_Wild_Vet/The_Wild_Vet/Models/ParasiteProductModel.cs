﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
namespace The_Wild_Vet.Models
{
    // Used https://app.quicktype.io/ and then pasted the json(using C#).
    public class TypeModel:BaseModel
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("fulfilmentlist")]
        public List<FulfilmentModel> Fulfilmentlist { get; set; }
    }

    public class FulfilmentModel : BaseModel
    { 
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("children")]
        public List<ChildModel> Children { get; set; }

        [JsonProperty("fulfil")]
        public string Fulfil { get; set; }

    }

    public class ChildModel : BaseModel
    {
        [JsonProperty("id")]
        public long Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }

}
