﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace The_Wild_Vet.Models
{
    public class BreedModel : BaseModel
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        [JsonProperty("img")]
        public string Img { get; set; }
        [JsonProperty("title")]
        public string Title { get; set; }
        [JsonProperty("childrens")]
        public List<BreedModel> Childrens { get; set; }

    }
}
