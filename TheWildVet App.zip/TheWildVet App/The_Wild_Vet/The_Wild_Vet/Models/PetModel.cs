﻿
using System;

using Newtonsoft.Json;
namespace The_Wild_Vet.Models
{
    public class PetModel 
    {
        public String Id { get; set; }
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public double? Weight { get; set; }
        public string DateOfBirth { get; set; }
        public String Gender { get; set; }
        public bool Microchipped { get; set; }
        public string Color { get; set; }
        public object Value { get; internal set; }

        [JsonProperty("breed")]
        public BreedModel Breed { get; set; }

        
    }
}