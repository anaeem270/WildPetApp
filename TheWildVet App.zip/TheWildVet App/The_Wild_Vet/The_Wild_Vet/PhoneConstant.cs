﻿using System;
namespace The_Wild_Vet
{
    public static class PhoneConstant
    {
        
        public static string VetPhoneNumber = "1300 945 383";
    }
}
