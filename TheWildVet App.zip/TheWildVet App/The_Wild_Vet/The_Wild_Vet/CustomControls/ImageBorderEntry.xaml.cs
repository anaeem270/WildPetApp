﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace The_Wild_Vet.CustomControls
{
    public partial class ImageBorderEntry : Grid
    {
     
        public ImageBorderEntry()
        {
            InitializeComponent();
            lblLabel.BindingContext = this;
            entry.BindingContext = this;
        }


        //Export keyboard type to make it customisable from the outside
        public static readonly BindableProperty KeyboardProperty = BindableProperty.Create(
        nameof(Keyboard),
        typeof(Keyboard),
        typeof(ImageBorderEntry),
        default(Keyboard),
        BindingMode.OneWay);
        public Keyboard Keyboard
        {
            get => (Keyboard)GetValue(KeyboardProperty);
            set => SetValue(KeyboardProperty, value);
        }

        //Export text entry to make it bind from the outside
        public static readonly BindableProperty TextProperty = BindableProperty.Create(
        nameof(Text),
        typeof(string),
        typeof(ImageBorderEntry),
        default(string),
        BindingMode.OneWay);
        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        //Export placeholder of entry to make it bind from the outside
        public static readonly BindableProperty PlaceholderProperty = BindableProperty.Create(
        nameof(Placeholder),
        typeof(string),
        typeof(ImageBorderEntry),
        default(string),
        BindingMode.OneWay);
        public string Placeholder
        {
            get => (string)GetValue(PlaceholderProperty);
            set => SetValue(PlaceholderProperty, value);
        }

        //Export title entry to make it bind from the outside
        public static readonly BindableProperty LabelProperty = BindableProperty.Create(
        nameof(Label),
        typeof(string),
        typeof(ImageBorderEntry),
        default(string),
        BindingMode.OneWay);
        public string Label
        {
            get => (string)GetValue(LabelProperty);
            set => SetValue(LabelProperty, value);
        }


    }
}
