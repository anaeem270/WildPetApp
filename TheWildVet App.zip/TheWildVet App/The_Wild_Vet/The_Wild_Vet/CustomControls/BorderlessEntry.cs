﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace The_Wild_Vet.CustomControls
{
    public class BorderlessEntry : Entry
    {
    }
}
