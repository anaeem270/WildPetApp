﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using The_Wild_Vet.Models;
using Xamarin.Forms;

namespace The_Wild_Vet.CustomControls
{
    public partial class ImageBorderPicker : Grid
    {
        public ImageBorderPicker()
        {
            InitializeComponent();
            lblLabel.BindingContext = this;
            imgHeader.BindingContext = this;
            //entry.BindingContext = this;
            picker.BindingContext = this;
        }

        //Export Breed picker
        public static readonly BindableProperty BreedParentProperty = BindableProperty.Create(
    nameof(BreedParent),
    typeof(BreedModel),
    typeof(ImageBorderPicker),
    default(BreedModel),
    BindingMode.OneWay);
        public BreedModel BreedParent
        {
            get => (BreedModel)GetValue(BreedParentProperty);
            set => SetValue(BreedParentProperty, value);
        }

        //Export Selected item from picker to make it bind from outside
        public static readonly BindableProperty SelectedItemProperty = BindableProperty.Create(
    nameof(SelectedItem),
    typeof(BreedModel),
    typeof(ImageBorderPicker),
    default(BreedModel),
    BindingMode.OneWay);
        public BreedModel SelectedItem
        {
            get => (BreedModel)GetValue(SelectedItemProperty);
            set => SetValue(SelectedItemProperty, value);
        }

        public static readonly BindableProperty SelectCommandProperty = BindableProperty.Create(
    nameof(SelectCommand),
    typeof(ICommand),
    typeof(ImageBorderPicker),
    default(ICommand),
    BindingMode.OneWay);
        public ICommand SelectCommand
        {
            get => (ICommand)GetValue(SelectCommandProperty);
            set => SetValue(SelectCommandProperty, value);
        }

        //Export Image header from picker to make it bind from the outside
        public static readonly BindableProperty ImageHeaderProperty = BindableProperty.Create(
    nameof(ImageHeader),
    typeof(string),
    typeof(ImageBorderEntry),
    default(string),
    BindingMode.OneWay);
        public string ImageHeader
        {
            get => (string)GetValue(ImageHeaderProperty);
            set => SetValue(ImageHeaderProperty, value);
        }

        //Export Text from picker to make it bind from the outside
        public static readonly BindableProperty TextProperty = BindableProperty.Create(
    nameof(Text),
    typeof(string),
    typeof(ImageBorderEntry),
    default(string),
    BindingMode.OneWay);
        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        //Export placeholder from picker to make it bind from outside
        public static readonly BindableProperty PlaceholderProperty = BindableProperty.Create(
    nameof(Placeholder),
    typeof(string),
    typeof(ImageBorderEntry),
    default(string),
    BindingMode.OneWay);
        public string Placeholder
        {
            get => (string)GetValue(PlaceholderProperty);
            set => SetValue(PlaceholderProperty, value);
        }

        //Export title from picker to make it bind from outside
        public static readonly BindableProperty LabelProperty = BindableProperty.Create(
    nameof(Label),
    typeof(string),
    typeof(ImageBorderEntry),
    default(string),
    BindingMode.OneWay);
        public string Label
        {
            get => (string)GetValue(LabelProperty);
            set => SetValue(LabelProperty, value);
        }

        void picker_SelectedIndexChanged(System.Object sender, System.EventArgs e)
        {
            SelectCommand?.Execute((BreedParent, SelectedItem));
        }
    }
}