﻿using System;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using The_Wild_Vet.Models;
using Firebase.Storage;
using The_Wild_Vet.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Firebase.Database;
using Firebase.Database.Query;

namespace The_Wild_Vet.Services
{
    public class RestfulApiService 

    {
        // Accessing Firebase Realtime database, Storage and Authentication
        FirebaseClient firebase = new FirebaseClient("https://thewildvetapp-default-rtdb.asia-southeast1.firebasedatabase.app/s");
        FirebaseStorage firebaseStorage = new FirebaseStorage("thewildvetapp.appspot.com");
        public string api = "AIzaSyAq5IETHtkNBG571c0H7O4bQUJrn2EiE_0";
        public string CurrentEmailId { set; get; }
        public string SelectedPet { get; set; }

        // to upload photo to firebase database.
        public async Task<string> UploadFile(Stream fileStream, string fileName)
        {
              var imageUrl = await firebaseStorage
                  .Child("Pets")
                  .Child(fileName)
                  .PutAsync(fileStream);  
             return imageUrl;
        }

        // Adding Pets to the database using the following parameters
        public async Task AddPets(string Name, bool microchipped, string DOB, double? weight, string Isfemale, string color,BreedModel breed,string ImageUrl,string Id)
        {
            await firebase
              .Child("Pets")
              .PostAsync(new PetModel() { Microchipped = microchipped, Name = Name, DateOfBirth = DOB, Weight = weight, Gender = Isfemale, Color = color , Breed=breed,ImageUrl=ImageUrl,Id=Id});
        }

        // Update Pet details with id to query and than imageurl to add refrence

        public async Task UpdatePet(string petname,string ImageUrl)
        {
             var toUpdatePet = (await firebase
                   .Child("Pets")
                   .OnceAsync<PetModel>()).Where(a => a.Object.Id == CurrentEmailId && a.Object.Name == petname).FirstOrDefault();
            toUpdatePet.Object.ImageUrl = ImageUrl;
                 await firebase
                   .Child("Pets")
                   .Child(toUpdatePet.Key)
                   .PutAsync( toUpdatePet.Object);
        }

        // To update Pet Details from Execute Pet Detail Page.

        public async Task UpdatePetDetail(string petname, string ImageUrl, double Weight , bool Microchipped)
        {

            var toUpdatePet = (await firebase
                 .Child("Pets")
                 .OnceAsync<PetModel>()).Where(a => a.Object.Id == CurrentEmailId && a.Object.Name == petname).FirstOrDefault();
            toUpdatePet.Object.ImageUrl = ImageUrl;
            toUpdatePet.Object.Weight = Weight;
            toUpdatePet.Object.Microchipped = Microchipped;
            await firebase
              .Child("Pets")
              .Child(toUpdatePet.Key)
              .PutAsync(toUpdatePet.Object);
        }

        // To delete Pets.
        public async Task DeletePet(string petname)
        {
            var toDeletePet = (await firebase
                   .Child("Pets")
                   .OnceAsync<PetModel>()).Where(a => a.Object.Id == CurrentEmailId && a.Object.Name == petname).FirstOrDefault();
            await firebase.Child("Pets").Child(toDeletePet.Key).DeleteAsync();
           

        }

        // To Get A Pet by Id = Email Address and display it as a list of pets.
        public async Task<List<PetModel>> GetPet(String Id)
        { 

            var allPets = await GetAllPets();
            return allPets.Where(a => a.Id == Id).ToList();
        }

     // To Get Selected Pet by name and id to display specific pet details.
        public async Task<PetModel> GetPets(string petname)
        {
            var useremail = CurrentEmailId;
            var PetProfiles = await GetAllPets();
            await firebase
              .Child("Pets")
              .OnceAsync<PetModel>();
            return PetProfiles.Where(a => a.Id == useremail && a.Name == petname).FirstOrDefault();

        }


        // To Get A pet by Id = Email address and display it as Object.
        public async Task <PetModel>  GetPets()
        {
         return   (await firebase
          .Child("Pets")
          .OnceAsync<PetModel>()).Select(item => new PetModel
          {
              Name = item.Object.Name,
              Id = item.Object.Id,
              ImageUrl = item.Object.ImageUrl,
              Microchipped = item.Object.Microchipped,
              Color = item.Object.Color,
              Gender = item.Object.Gender,
              Breed = item.Object.Breed,
              DateOfBirth = item.Object.DateOfBirth,
              Weight = item.Object.Weight,

          }).FirstOrDefault();
        }

        // getting Api instance to use in BaseViewModel as parent class and then use in child classes.
        private static RestfulApiService instance = null;
        public static RestfulApiService Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new RestfulApiService();
                }
                return instance;
            }
        }

        //get all breed from json
        public BreedModel[] GetAllBreeds()
        {
            var assembly = typeof(RestfulApiService).GetTypeInfo().Assembly;
            using (Stream stream = assembly.GetManifestResourceStream("The_Wild_Vet.Services.Breed.json"))
            using (StreamReader r = new StreamReader(stream))
            {
                string json = r.ReadToEnd();
                return JsonConvert.DeserializeObject<BreedModel[]>(json);
            }
        }

        //get all pet from json
        public async Task<List<PetModel>> GetAllPets()
        {
            // string jsons= firebase.ToJson();
            return (await firebase
              .Child("Pets")
              .OnceAsync<PetModel>()).Select(item => new PetModel
              {
                  Name = item.Object.Name,
                  Id = item.Object.Id,
                  ImageUrl = item.Object.ImageUrl,
                  Microchipped = item.Object.Microchipped,
                  Breed = item.Object.Breed,
                  Color = item.Object.Color,
                  Gender = item.Object.Gender,
                  DateOfBirth = item.Object.DateOfBirth,
                  Weight = item.Object.Weight,
              }).ToList();

        }

       // getting a person by email id
        public async Task<PersonModel> GetPerson(String email)
        {
            var allPersons = await GetAllPersons();
            await firebase
              .Child("Persons")
              .OnceAsync<PersonModel>();
            return allPersons.Where(a => a.PersonId == email).FirstOrDefault();
        }

        // getting different persons in list
        public async Task<List<PersonModel>> GetAllPersons()
        {

            return (await firebase
              .Child("Persons")
              .OnceAsync<PersonModel>()).Select(item => new PersonModel
              {
                  Name = item.Object.Name,
                  PersonId = item.Object.PersonId,
                  ImgUrl = item.Object.ImgUrl,
                  DateofBirth=item.Object.DateofBirth,
                  Address=item.Object.Address
              }).ToList();
        }
        // adding a person to get him registered.
        public async Task AddPerson(string name, string Email, string DOB, string residence, string password)
        {

            await firebase
              .Child("Persons")
              .PostAsync(new PersonModel() { PersonId = Email, Name = name, DateofBirth = DOB, Address = residence, Password = password });
        }


        // Updating a person image from profile page
        public async Task UpdatePerson( string ImageUrl)
        {

            var toUpdatePerson = (await firebase
                 .Child("Persons")
                 .OnceAsync<PersonModel>()).Where(a => a.Object.PersonId == CurrentEmailId ).FirstOrDefault();
            toUpdatePerson.Object.ImgUrl = ImageUrl;
            await firebase
              .Child("Persons")
              .Child(toUpdatePerson.Key)
              .PutAsync(toUpdatePerson.Object);
        }

        //get all product from json
        public TypeModel[] GetAllProducts()
        {
            var assembly = typeof(RestfulApiService).GetTypeInfo().Assembly;
            using (Stream stream = assembly.GetManifestResourceStream("The_Wild_Vet.Services.Product.json"))
            using (StreamReader r = new StreamReader(stream))
            {
                string json = r.ReadToEnd();
                return JsonConvert.DeserializeObject<TypeModel[]>(json);
            }
        }

        //get all issue from json
        public IssueModel[] GetAllIssues()
        {
            var assembly = typeof(RestfulApiService).GetTypeInfo().Assembly;
            using (Stream stream = assembly.GetManifestResourceStream("The_Wild_Vet.Services.Support.json"))
            using (StreamReader r = new StreamReader(stream))
            {
                string json = r.ReadToEnd();
                return JsonConvert.DeserializeObject<IssueModel[]>(json);
            }
        }

    }
}





























