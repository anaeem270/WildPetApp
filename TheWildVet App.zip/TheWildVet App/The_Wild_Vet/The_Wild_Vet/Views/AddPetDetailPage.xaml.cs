﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace The_Wild_Vet.Views
{
    public partial class AddPetDetailPage : ContentPage
    {
        public AddPetDetailPage()
        {
            InitializeComponent();
        }
    }
}
