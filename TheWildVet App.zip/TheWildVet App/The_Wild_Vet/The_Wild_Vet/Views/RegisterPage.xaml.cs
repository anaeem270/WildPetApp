﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using The_Wild_Vet.Services;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using Firebase.Auth;


namespace The_Wild_Vet.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RegisterPage : ContentPage
    {
        public RegisterPage()
        {
            InitializeComponent();
        }

        //Navigate to login page and become the mainpage
        private  void Login_Tapped(object sender, EventArgs e)
        {
            App.Current.MainPage = new NavigationPage(new LoginPage());
        }

        //Method when Register button is clicked
        private async void Register_Clicked(object sender, EventArgs e)
        {
            try
            {
                RestfulApiService Api = new RestfulApiService();
                var authProvider = new FirebaseAuthProvider(new FirebaseConfig(Api.api));
                var auth = await authProvider.CreateUserWithEmailAndPasswordAsync(Email.Text, password.Text);

                string gettoken = auth.FirebaseToken;
                await App.Current.MainPage.DisplayAlert("Alert", "ID created please try login", "ok");

                await Api.AddPerson(fullName.Text, Email.Text, DOB.Text, Residence.Text, password.Text
                    );

                fullName.Text = string.Empty;
                Email.Text = string.Empty;
                DOB.Text = string.Empty;
                Residence.Text = string.Empty;
                password.Text = string.Empty;

                await DisplayAlert("Success", "Person Added Successfully", "OK");
                await Navigation.PushAsync(new LoginPage());
                //var allPersons = await person.GetAllPersons();

            }
            catch (Exception ex)
            {

                await App.Current.MainPage.DisplayAlert("Alert", ex.Message, "OK");

            }

        }
      
    }
}