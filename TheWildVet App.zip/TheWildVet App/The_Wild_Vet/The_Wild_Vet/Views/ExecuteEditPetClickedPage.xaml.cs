﻿using System;
using System.Collections.Generic;


using Xamarin.Forms.Xaml;

using Xamarin.Forms;

namespace The_Wild_Vet.Views
{
    public partial class ExecuteEditPetClickedPage : ContentPage
    {
        public ExecuteEditPetClickedPage()
         
        {
            InitializeComponent();
            
        }

        //Method to navigate back to Dashboard of the back button
        private async void Go_Back_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new DashboardPage());
            
        }
    }
}
