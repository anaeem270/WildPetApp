﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace The_Wild_Vet.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AppointmentsPage : ContentPage
    {
        Label label = new Label { Text = "Online Bookings for a vaccination are currently unavailable\n" +
            "Please call us by using the button below for further Assistance\n" + "Thank you!"};
          public AppointmentsPage()
        {
            InitializeComponent();
        
        }

        // Accessing the dashboard(flyout page) as mainpage where ispresented is used to hide it.
        private void On_SideMenu_Clicked(object sender, EventArgs e)
        {
            if ((Application.Current.MainPage as MainPage).IsPresented == false)
            {
                (Application.Current.MainPage as MainPage).IsPresented = true;
            }
            else
            {
                (Application.Current.MainPage as MainPage).IsPresented = false;
            }
        }

        //Method to hide vaccination section if the button is clicked
        private async void VaccinationClicked(object sender, EventArgs e)
        {
            VaccinationSection.IsVisible = true;
            PetAppointmentSection.IsVisible = false;
            
        }

        //Once back button is clicked hide section and show the other
        private async void BackClicked(object sender, EventArgs e)
        {
            PetAppointmentSection.IsVisible = true;
            VaccinationSection.IsVisible = false;
        }

        //Method to return back to dashboard once done button is clicked
        private async void DoneClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new DashboardPage());
        }

        //Method that redirects to phone dialer once button is clicked.
        private async void CallUsButton(object sender, EventArgs e)
        {
            Xamarin.Essentials.PhoneDialer.Open(PhoneConstant.VetPhoneNumber);
        }

        //Method to navigate to the parasite prevention screen once button is clicked
        private async void ParasiteClicked(object sender, EventArgs e)
        {

            await Navigation.PushAsync(new PreventionPage());
        }
    }
}