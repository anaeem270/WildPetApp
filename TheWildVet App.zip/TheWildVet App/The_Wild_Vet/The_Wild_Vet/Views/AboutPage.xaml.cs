﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;

namespace The_Wild_Vet.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }


        //The side menu page will hide if the main page is present or else
        //it would be shown
        private void On_SideMenu_Clicked(object sender, EventArgs e)
        {
            if ((Application.Current.MainPage as MainPage).IsPresented == false)
            {
                (Application.Current.MainPage as MainPage).IsPresented = true;
            }
            else
            {
                (Application.Current.MainPage as MainPage).IsPresented = false;
            }
        }

        // To go back to the dashboard once the go back button is clicked.
        private async void Go_Back_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new DashboardPage());
        }

        // When the image of the map is clicked it would navigate to the map app.
        private async void Map_Clicked(System.Object sender, System.EventArgs e)
        {
            await Map.OpenAsync(-33.876920, 151.188220);
        }
    }
}