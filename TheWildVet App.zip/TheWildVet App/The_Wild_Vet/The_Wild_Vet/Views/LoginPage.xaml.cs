﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using Firebase.Auth;
using Newtonsoft.Json;
using Xamarin.Essentials;
using The_Wild_Vet.Models;
using The_Wild_Vet.Services;
using The_Wild_Vet.ViewModels;

namespace The_Wild_Vet.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        RestfulApiService Api = new RestfulApiService();

        


        public LoginPage()
        {
            InitializeComponent();
       

            
            
        }

        private async void Register_Tapped(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new RegisterPage());
        }

        private async void Login_Clicked(object sender, EventArgs e)
        {

           
            var authProvider = new FirebaseAuthProvider(new FirebaseConfig(Api.api));

            try
            {
               
                var auth = await authProvider.SignInWithEmailAndPasswordAsync(Email.Text, password.Text);

                
                var content = await auth.GetFreshAuthAsync();
                var serializedcontnet = JsonConvert.SerializeObject(content);
                Preferences.Set("MyFirebaseRefreshToken", serializedcontnet);



                BindingContext = new LoginPersonViewModel(Email.Text);

                
                await Navigation.PushAsync(new DashboardPage());
                


            }

            catch (Exception)
            {
                await App.Current.MainPage.DisplayAlert("Alert", "Invalid Email and Password", "OK");
                
            }
        }

     
    }
}